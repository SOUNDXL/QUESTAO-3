<script>
function inverterTexto() {
    // Obtém o conteúdo do primeiro textarea
    let inputContent = document.getElementById("inputText").value.trim();

    // Divide o conteúdo em palavras
    let wordsArray = inputContent.split(/\s+/);

    // Inverte a ordem das palavras
    let reversedWords = wordsArray.reverse();

    // Constrói o texto invertido
    let reversedText = reversedWords.join(" ");

    // Coloca o texto invertido no segundo textarea
    document.getElementById("outputText").value = reversedText;
}
</script>

</body>
</html>